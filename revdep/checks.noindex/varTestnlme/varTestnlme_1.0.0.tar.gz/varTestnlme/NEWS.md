# varTestnlme 1.0.0

Change the structure of the package for a more modular one. Now the main function returns an object of class htest, which can be printed for example via the print() function of package EnvStats. To avoid conflicts with the varTest function of EnvStats package, the main function of our package was renamed from varTest to varCompTest.
Parametric bootstrap for the estimation of the FIM is now available for the saemix package also.

# varTestnlme 0.2.0

Add the computation of the FIM via parametric bootstrap for models fitted with nlme and lme4 packages

# varTestnlme 0.1.0

This is the first release of varTestnlme
